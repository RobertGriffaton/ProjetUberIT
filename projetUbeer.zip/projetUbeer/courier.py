import redis
import json
import time
import argparse
import random
import uuid

CHANNEL_ANNONCES = "annonces.new"
CHANNEL_CANDIDATURES = "candidatures.new"
CHANNEL_SELECTION = "annonces.selection"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--courier-id", type=str, default=str(uuid.uuid4())[:8],
                        help="Identifiant du livreur (sinon généré aléatoirement)")
    parser.add_argument("--eta-min", type=int, default=2, help="ETA minimal en minutes")
    parser.add_argument("--eta-max", type=int, default=15, help="ETA maximal en minutes")
    parser.add_argument("--listen-selection", type=int, default=15,
                        help="Durée (en secondes) d'écoute des sélections après candidature")
    args = parser.parse_args()

    courier_id = args.courier_id
    r = redis.Redis()

    print(f"[LIVREUR {courier_id}] Démarré. En attente d'annonces...")

    ps = r.pubsub()
    ps.subscribe(CHANNEL_ANNONCES)

    for message in ps.listen():
        if message.get("type") != "message":
            continue
        try:
            annonce = json.loads(message["data"])
        except Exception:
            continue

        if annonce.get("type") != "ANNONCE":
            continue

        order_id = annonce.get("order_id")
        print(f"[LIVREUR {courier_id}] 📢 Nouvelle annonce reçue: {order_id}")

        # Générer un ETA aléatoire
        eta = random.randint(args.eta_min, args.eta_max)

        # Envoyer la candidature
        candidature = {
            "type": "CANDIDATURE",
            "order_id": order_id,
            "courier_id": courier_id,
            "eta": eta
        }
        r.publish(CHANNEL_CANDIDATURES, json.dumps(candidature))
        print(f"[LIVREUR {courier_id}] ✉️ Candidature envoyée pour {order_id} avec ETA={eta} min")

        # Écoute la sélection pendant N secondes
        ps_sel = r.pubsub()
        ps_sel.subscribe(CHANNEL_SELECTION)
        t_end = time.monotonic() + args.listen_selection

        for s in ps_sel.listen():
            if s.get("type") != "message":
                continue
            try:
                sel = json.loads(s["data"])
            except Exception:
                continue

            if sel.get("type") != "SELECTION":
                continue

            if sel.get("courier_id") == courier_id and sel.get("order_id") == order_id:
                print(f"[LIVREUR {courier_id}] ✅ Affecté sur {order_id} | Récompense: {sel.get('reward_eur')}€")
                break

            if time.monotonic() >= t_end:
                print(f"[LIVREUR {courier_id}] ⏱️ Pas choisi pour {order_id}.")
                break


if __name__ == "__main__":
    main()
