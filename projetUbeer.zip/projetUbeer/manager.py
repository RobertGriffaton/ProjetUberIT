# manager.py — version non-bloquante + mode manuel
import redis
import json
import time
import argparse
import random
import uuid
import csv
import os

CHANNEL_ANNONCES = "annonces.new"
CHANNEL_CANDIDATURES = "candidatures.new"
CHANNEL_SELECTION = "annonces.selection"


def load_random_restaurant(csv_file: str):
    """Charge un restaurant au hasard (colonnes tolérées: name/restaurant_name, latitude/lat, longitude/lon)."""
    if not os.path.exists(csv_file):
        return {"name": "Fallback Bistro", "lat": 48.8566, "lon": 2.3522}

    with open(csv_file, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
        if not rows:
            return {"name": "Fallback Bistro", "lat": 48.8566, "lon": 2.3522}
        r = random.choice(rows)

        name = r.get("name") or r.get("restaurant_name") or "Restaurant"
        lat  = r.get("latitude") or r.get("lat") or "48.8566"
        lon  = r.get("longitude") or r.get("lon") or "2.3522"
        return {"name": name, "lat": float(lat), "lon": float(lon)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", type=str, default="restaurants.csv", help="Fichier CSV des restaurants")
    parser.add_argument("--timeout", type=float, default=5.0, help="Temps (s) pour collecter les candidatures")
    parser.add_argument("--reward", type=float, default=8.5, help="Récompense en euros")
    parser.add_argument("--mode", choices=["auto", "manual"], default="manual",
                        help="auto = plus petit ETA ; manual = choix interactif (défaut)")
    args = parser.parse_args()

    # Connexion Redis (decode_responses=True pour avoir des str)
    r = redis.Redis(host="localhost", port=6379, decode_responses=True)

    # 1) Publier l'annonce
    order_id = str(uuid.uuid4())[:8]
    resto = load_random_restaurant(args.csv)
    annonce = {
        "type": "ANNONCE",
        "order_id": order_id,
        "pickup": {"name": resto["name"], "lat": resto["lat"], "lon": resto["lon"]},
        "dropoff": {"name": "Client X", "lat": resto["lat"] + 0.01, "lon": resto["lon"] + 0.01},
        "reward_eur": args.reward,
    }
    r.publish(CHANNEL_ANNONCES, json.dumps(annonce))
    print(f"[MANAGER] 📢 Nouvelle annonce publiée: {order_id} ({resto['name']}) | reward={args.reward:.2f}€")

    # 2) Collecter les candidatures pendant timeout (boucle NON-BLOQUANTE)
    ps = r.pubsub()
    ps.subscribe(CHANNEL_CANDIDATURES)
    candidatures = []
    deadline = time.monotonic() + args.timeout
    print(f"[MANAGER] ⏳ Collecte des candidatures pendant {args.timeout:.1f}s…")

    # Important: utiliser get_message() + sleep court → pas de blocage
    while time.monotonic() < deadline:
        msg = ps.get_message(ignore_subscribe_messages=True)
        if msg and msg.get("type") == "message":
            try:
                cand = json.loads(msg["data"])
            except Exception:
                cand = None
            if cand and cand.get("type") == "CANDIDATURE" and cand.get("order_id") == order_id:
                candidatures.append(cand)
                print(f"[MANAGER] 📥 Candidature: {cand['courier_id']} (ETA={cand['eta']} min)")
        time.sleep(0.05)  # respiration CPU + donne du temps aux livreurs

    if not candidatures:
        print("[MANAGER] ❌ Aucune candidature reçue.")
        return

    # 3) Choix (auto ou manuel)
    chosen = min(candidatures, key=lambda c: c["eta"])
    if args.mode == "manual":
        print("\n[MANAGER] Candidatures reçues :")
        for i, c in enumerate(candidatures, 1):
            print(f"  {i}. {c['courier_id']}  (ETA {c['eta']} min)")
        raw = input("[MANAGER] Numéro du livreur à accepter (Entrée = meilleur ETA) : ").strip()
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(candidatures):
                chosen = candidatures[idx - 1]
            else:
                print("[MANAGER] Numéro invalide — meilleur ETA conservé.")
        elif raw:
            # Saisie directe d'un courier_id
            tmp = next((c for c in candidatures if c["courier_id"] == raw), None)
            if tmp:
                chosen = tmp
            else:
                print("[MANAGER] ID inconnu — meilleur ETA conservé.")

    # 4) Publier la sélection
    selection = {
        "type": "SELECTION",
        "order_id": order_id,
        "courier_id": chosen["courier_id"],
        "eta": chosen["eta"],
        "reward_eur": args.reward,
    }
    r.publish(CHANNEL_SELECTION, json.dumps(selection))
    print(f"[MANAGER] ✅ Sélection: {chosen['courier_id']} (ETA={chosen['eta']} min)")

if __name__ == "__main__":
    main()
