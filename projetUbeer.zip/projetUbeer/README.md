# Redis UberEats POC (ultra simple)
- Manager publie une annonce (pickup depuis `restaurants.csv`, dropoff proche, reward).
- Livreurs répondent avec un ETA (aléatoire) ; le manager sélectionne et notifie.

## Lancer
1) Avoir Redis lancé (Windows: Memurai ou Redis for Windows, Linux/macOS: `redis-server`).
2) Installer deps: `pip install -r requirements.txt`
3) Ouvrir 2+ consoles:
   - Console 1..N: `python courier.py --courier-id courier_101` (répéter avec d'autres IDs)
   - Console Manager: `python manager.py --csv restaurants.csv --timeout 5 --reward 8.5`

## Fichiers
- `manager.py`, `courier.py`
- `restaurants.csv` (mini base de restos; remplacez par Kaggle + mêmes colonnes)

## Canaux Redis
- `annonces.new`, `candidatures.new`, `annonces.selection`
