# coursier.py — aucun argument requis
import json, math, os, random, socket, time, uuid
import redis

CHANNEL_ANNONCES      = "annonces.new"
CHANNEL_CANDIDATURES  = "candidatures.new"
CHANNEL_SELECTION     = "annonces.selection"

# Réglages par défaut
REDIS_URL      = "redis://localhost:6379/0"
VITESSE_KMH    = 14.0
DELAI_FIXE_MIN = 2.0
CENTER_LAT     = 48.8660
CENTER_LON     = 2.3350

NAMES = ["Alex","Sam","Robin","Camille","Noa","Lina","Mael","Eli","Nora","Rayan","Milan","Yanis","Léa","Jules","Zoé","Léo","Inès","Sacha","Aya","Nils"]

def unique_id(prefix="c"):
    host = socket.gethostname().split(".")[0]
    pid = os.getpid()
    short = str(uuid.uuid4())[:4]
    return f"{prefix}_{host}_{pid}_{short}"

def pick_name():
    return f"{random.choice(NAMES)}-{str(uuid.uuid4())[:3]}"

def jitter_position(lat0, lon0, spread_km=0.15):
    # ~150 m d'écart aléatoire
    d_km_lat = random.gauss(0, spread_km)
    d_km_lon = random.gauss(0, spread_km)
    dlat = d_km_lat / 111.0
    dlon = d_km_lon / (111.0 * max(0.1, math.cos(math.radians(lat0))))
    return lat0 + dlat, lon0 + dlon

def haversine_km(a_lat, a_lon, b_lat, b_lon):
    R = 6371.0
    dlat = math.radians(b_lat - a_lat)
    dlon = math.radians(b_lon - a_lon)
    lat1 = math.radians(a_lat); lat2 = math.radians(b_lat)
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2*R*math.asin(math.sqrt(h))

def eta_from_km(km):
    minutes = (km / max(1e-6, VITESSE_KMH)) * 60.0 + DELAI_FIXE_MIN
    return max(1, int(round(minutes + random.uniform(-0.2, 0.4))))

def main():
    # Identité & position uniques, sans paramètres
    coursier_id = unique_id()
    name = pick_name()
    lat, lon = jitter_position(CENTER_LAT, CENTER_LON, 0.3)

    r = redis.from_url(REDIS_URL, decode_responses=True)
    sub = r.pubsub(); sub.subscribe(CHANNEL_ANNONCES, CHANNEL_SELECTION)

    print(f"[COURSIER {coursier_id}] En ligne | nom={name} | pos=({lat:.5f},{lon:.5f}) | v={VITESSE_KMH}km/h")

    pending = set()

    try:
        for msg in sub.listen():
            if msg.get("type") != "message":
                continue
            try:
                data = json.loads(msg["data"])
            except Exception:
                continue

            if data.get("type") == "ANNONCE":
                order_id = data.get("order_id")
                if not order_id or order_id in pending:
                    continue
                pickup = data.get("pickup") or {}
                drop   = data.get("dropoff") or {}
                if not pickup or not drop:
                    print(f"[{coursier_id}] ⚠️ annonce mal formée"); 
                    continue

                d1 = haversine_km(lat, lon, float(pickup["lat"]), float(pickup["lon"]))
                d2 = haversine_km(float(pickup["lat"]), float(pickup["lon"]), float(drop["lat"]), float(drop["lon"]))
                total_km = d1 + d2
                eta = eta_from_km(total_km)

                print(f"[COURSIER {coursier_id}] 📣 Annonce {order_id} | dist≈{total_km:.2f} km | ETA={eta} min | prime≈{data.get('reward_eur','?')}€")
                # Demande d'acceptation (aucun paramètre à passer)
                try:
                    choice = input(f"[{name}] Accepter ? (o/N) ").strip().lower()
                except EOFError:
                    choice = "n"
                if choice == "o":
                    cand = {
                        "type": "CANDIDATURE",
                        "order_id": order_id,
                        "courier_id": coursier_id,
                        "name": name,
                        "eta_min": eta,
                        "position": {"lat": lat, "lon": lon},
                        "sent_at": int(time.time()),
                    }
                    r.publish(CHANNEL_CANDIDATURES, json.dumps(cand))
                    pending.add(order_id)
                    print(f"[COURSIER {coursier_id}] 📨 Candidature envoyée (ETA={eta} min)")
                else:
                    print(f"[COURSIER {coursier_id}] ❌ Refusée")
            elif data.get("type") == "SELECTION":
                if data.get("courier_id") == coursier_id:
                    print(f"[COURSIER {coursier_id}] ✅ Sélectionné pour {data['order_id']} | {data.get('reward_eur','?')}€ | ETA {data.get('eta_min','?')} min")
                    pending.discard(data["order_id"])
    except KeyboardInterrupt:
        print("\n[COURSIER] Arrêt demandé. Bye.")
    finally:
        try: sub.close()
        except: pass

if __name__ == "__main__":
    main()
