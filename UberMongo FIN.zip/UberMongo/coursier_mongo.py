# coursier_mongo.py
import os, time, math, random, uuid, socket
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()
URI = os.getenv("MONGODB_URI")
DBNAME = os.getenv("DB_NAME", "ubeer")

VITESSE_KMH = 14.0
CENTER_LAT, CENTER_LON = 48.8660, 2.3350
JITTER_KM = 0.3
TICK_SEC = 1.0
PAUSE_S = 2

NAMES = ["Alex","Sam","Robin","Camille","Noa","Lina","Mael","Eli","Nora","Rayan","Milan","Yanis","Léa","Jules","Zoé","Léo","Inès","Sacha","Aya","Nils"]

def unique_id(prefix="c"):
    host = socket.gethostname().split(".")[0]
    return f"{prefix}_{host}_{str(uuid.uuid4())[:6]}"

def jitter(lat0, lon0, spread_km=JITTER_KM):
    dlat = random.gauss(0, spread_km) / 111.0
    dlon = random.gauss(0, spread_km) / (111.0 * max(0.1, math.cos(math.radians(lat0))))
    return lat0 + dlat, lon0 + dlon

def hav(a_lat,a_lon,b_lat,b_lon):
    R=6371.0
    dlat=math.radians(b_lat-a_lat); dlon=math.radians(b_lon-a_lon)
    lat1=math.radians(a_lat); lat2=math.radians(b_lat)
    h=math.sin(dlat/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2*R*math.asin(math.sqrt(h))

def lerp(a,b,t): return a+(b-a)*t

def move_and_track(db, order_id, courier, start, target, status_label, planned_s, global_remaining_s):
    tracking = db.tracking
    steps = max(5, int(planned_s // TICK_SEC))
    t0 = time.time()
    last_shown = -25  # n'émettre que 0/25/50/75/100
    for step in range(steps+1):
        t = step/steps
        lat = lerp(start[0], target[0], t); lon = lerp(start[1], target[1], t)
        progress = int(round(t*100))
        if progress - last_shown < 25 and progress != 100:
            time.sleep(TICK_SEC); continue
        last_shown = progress
        elapsed = time.time() - t0
        local_eta  = max(0, int(planned_s - elapsed))
        global_eta = max(0, int(global_remaining_s - elapsed))
        tracking.insert_one({
            "type":"TRACK",
            "order_id":order_id,
            "courier_id":courier["id"],
            "name":courier["name"],
            "status":status_label,
            "lat":lat,"lon":lon,
            "progress":progress,
            "eta_s":local_eta,
            "global_eta_s":global_eta,
            "sent_at":int(time.time())
        })
        time.sleep(TICK_SEC)
    tracking.insert_one({
        "type":"TRACK",
        "order_id":order_id,
        "courier_id":courier["id"],
        "name":courier["name"],
        "status":f"{status_label}_arrived",
        "lat":target[0],"lon":target[1],
        "progress":100,"eta_s":0,
        "global_eta_s":max(0, int(global_remaining_s - planned_s)),
        "sent_at":int(time.time())
    })

def main():
    client = MongoClient(URI); db = client[DBNAME]
    orders = db.orders; cands = db.candidatures; assignments = db.assignments

    courier = {"id": unique_id(), "name": f"{random.choice(NAMES)}-{str(uuid.uuid4())[:3]}"}
    lat, lon = jitter(CENTER_LAT, CENTER_LON, JITTER_KM)
    print(f"[COURSIER {courier['id']}] En ligne | {courier['name']} | pos=({lat:.5f},{lon:.5f})")

    try:
        with orders.watch([{"$match":{"operationType":"insert","fullDocument.type":"ORDER"}}], full_document='updateLookup') as stream:
            for ch in stream:
                order = ch["fullDocument"]; order_id = order["_id"]
                try:
                    ans = input(f"[{courier['name']}] Accepter la commande {order_id} (o/N) ? ").strip().lower()
                except EOFError:
                    ans = "n"
                if ans != "o":
                    print(f"[{courier['id']}] ❌ refuse {order_id}"); continue

                # candidature (le manager calculera l'ETA avec la position)
                cands.insert_one({
                    "type":"CANDIDATURE",
                    "order_id": order_id,
                    "courier_id": courier["id"],
                    "name": courier["name"],
                    "position": {"lat": lat, "lon": lon},
                    "sent_at": int(time.time())
                })
                print(f"[{courier['id']}] 📨 candidature envoyée pour {order_id}")

                # Attente d'une assignment pour CET order_id & ce coursier
                with assignments.watch([{"$match":{
                    "operationType":"insert",
                    "fullDocument.order_id": order_id,
                    "fullDocument.courier_id": courier["id"]
                }}], full_document='updateLookup') as s2:
                    for ev in s2:
                        sel = ev["fullDocument"]
                        print(f"[{courier['id']}] ✅ sélectionné pour {order_id}")
                        pickup = sel["pickup"]; dropoff = sel["dropoff"]
                        target_total_s = max(5, int(sel.get("eta_min", 10)*60))

                        d_pick = hav(lat,lon,float(pickup["lat"]),float(pickup["lon"]))
                        d_drop = hav(float(pickup["lat"]),float(pickup["lon"]),float(dropoff["lat"]),float(dropoff["lon"]))
                        dur_pick = (d_pick /  max(1e-6, VITESSE_KMH)) * 3600
                        dur_drop = (d_drop / max(1e-6, VITESSE_KMH)) * 3600
                        total_raw = max(1.0, dur_pick + PAUSE_S + dur_drop)
                        scale = target_total_s / total_raw
                        dur_pick *= scale; dur_drop *= scale
                        global_remaining = dur_pick + PAUSE_S + dur_drop

                        # Trajet 1
                        move_and_track(db, order_id, courier, (lat,lon),
                                       (float(pickup["lat"]),float(pickup["lon"])),
                                       "vers_resto", dur_pick, global_remaining)
                        time.sleep(PAUSE_S)

                        # Trajet 2
                        lat, lon = float(pickup["lat"]), float(pickup["lon"])
                        global_remaining -= dur_pick + PAUSE_S
                        move_and_track(db, order_id, courier, (lat,lon),
                                       (float(dropoff["lat"]),float(dropoff["lon"])),
                                       "vers_client", dur_drop, global_remaining)

                        # Fin
                        db.tracking.insert_one({
                            "type":"TRACK","order_id":order_id,"courier_id":courier["id"],"name":courier["name"],
                            "status":"livre","lat":float(dropoff["lat"]), "lon":float(dropoff["lon"]),
                            "progress":100,"eta_s":0,"global_eta_s":0,"sent_at":int(time.time())
                        })
                        print(f"[{courier['id']}] 📦 Livraison terminée pour {order_id}")
                        break
    except KeyboardInterrupt:
        print("\n[COURSIER] Stop.")
    finally:
        client.close()

if __name__ == "__main__":
    main()
