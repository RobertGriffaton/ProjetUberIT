# manager_mongo.py — 100% MongoDB avec sélection MANUELLE ou AUTO (Entrée)
import os, time, math
from pymongo import MongoClient, ASCENDING
from dotenv import load_dotenv

load_dotenv()
URI = os.getenv("MONGODB_URI")
DBNAME = os.getenv("DB_NAME", "ubeer")

REWARD_EUR  = 8.5
TIMEOUT_S   = 30          # fenêtre de collecte des candidatures
VITESSE_KMH = 14.0
DELAI_FIXE_MIN = 2.0      # buffer (prise en charge, feux, etc.)

def haversine_km(a_lat, a_lon, b_lat, b_lon):
    R = 6371.0
    dlat = math.radians(b_lat - a_lat)
    dlon = math.radians(b_lon - a_lon)
    lat1 = math.radians(a_lat); lat2 = math.radians(b_lat)
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2*R*math.asin(math.sqrt(h))

def eta_minutes_from(c_pos, pickup, drop):
    d1 = haversine_km(float(c_pos["lat"]), float(c_pos["lon"]),
                      float(pickup["lat"]), float(pickup["lon"]))
    d2 = haversine_km(float(pickup["lat"]), float(pickup["lon"]),
                      float(drop["lat"]), float(drop["lon"]))
    minutes = ((d1 + d2) / max(1e-6, VITESSE_KMH)) * 60.0 + DELAI_FIXE_MIN
    return max(1, int(round(minutes)))

def load_restaurants_from_mongo(db):
    """Construit {restaurant_name: {lat, lon}} depuis la collection 'restaurants'."""
    mapping = {}
    coll = db.restaurants
    coll.create_index([("restaurant", ASCENDING)])
    for doc in coll.find({}, {"restaurant": 1, "latitude": 1, "longitude": 1}):
        name = doc.get("restaurant")
        lat  = doc.get("latitude")
        lon  = doc.get("longitude")
        if not name:
            continue
        try:
            lat = float(lat); lon = float(lon)
        except Exception:
            continue
        if name not in mapping:
            mapping[name] = {"lat": lat, "lon": lon}
    if not mapping:
        print("[MANAGER] ⚠️ Aucun restaurant trouvé dans 'restaurants'. Lance d’abord: python import_csv_to_mongo.py")
    else:
        print(f"[MANAGER] ✅ Restaurants chargés depuis Mongo ({len(mapping)} restos)")
    return mapping

def prompt_select_or_auto(cands_sorted):
    """
    Affiche les candidatures triées et propose:
    - saisir un numéro (1..N) pour choisir le livreur
    - appuyer sur Entrée pour sélection AUTOMATIQUE (meilleur ETA)
    """
    print("\n[MANAGER] 📊 Candidatures reçues :")
    for i, c in enumerate(cands_sorted, 1):
        print(f"  {i:>2}) courier_id={c['courier_id']:<22} nom={c.get('name','-'):<12} ETA={c.get('eta_min','?')} min")
    try:
        raw = input("[MANAGER] Choisir un livreur (1..N) ou appuyer sur Entrée pour auto : ").strip()
    except EOFError:
        raw = ""
    if raw == "":
        return cands_sorted[0]
    try:
        idx = int(raw)
        if 1 <= idx <= len(cands_sorted):
            return cands_sorted[idx - 1]
    except Exception:
        pass
    print("[MANAGER] Saisie invalide → sélection automatique.")
    return cands_sorted[0]

def main():
    client = MongoClient(URI)
    db = client[DBNAME]
    orders       = db.orders
    candidatures = db.candidatures
    assignments  = db.assignments

    candidatures.create_index([("order_id", ASCENDING), ("sent_at", ASCENDING)])
    assignments.create_index([("order_id", ASCENDING)])

    restos = load_restaurants_from_mongo(db)
    print("[MANAGER] En écoute des commandes (Mongo Change Streams)…")

    try:
        with orders.watch(
            [{"$match": {"operationType": "insert", "fullDocument.type": "ORDER"}}],
            full_document="updateLookup"
        ) as stream:
            for ch in stream:
                order = ch["fullDocument"]
                order_id   = order["_id"]
                resto_name = order["restaurant"]["name"]
                customer   = order["customer"]
                dropoff = {"lat": float(customer["lat"]), "lon": float(customer["lon"])}

                if resto_name not in restos:
                    print(f"[MANAGER] ❌ Restaurant inconnu dans Mongo: {resto_name}")
                    continue

                pickup = {"lat": float(restos[resto_name]["lat"]),
                          "lon": float(restos[resto_name]["lon"])}

                print(f"[MANAGER] 📣 Commande {order_id} ({resto_name}) — collecte des candidatures pendant {TIMEOUT_S}s…")

                # Collecte des candidatures pour cet order_id
                start = time.monotonic()
                cands = []
                with candidatures.watch(
                    [{"$match": {
                        "operationType": "insert",
                        "fullDocument.type": "CANDIDATURE",
                        "fullDocument.order_id": order_id
                    }}],
                    full_document="updateLookup"
                ) as cs:
                    while time.monotonic() - start < TIMEOUT_S:
                        ev = cs.try_next()
                        if not ev:
                            time.sleep(0.2)
                            continue
                        cand = ev["fullDocument"]
                        pos = cand.get("position") or {}
                        try:
                            eta = eta_minutes_from(
                                {"lat": float(pos["lat"]), "lon": float(pos["lon"])},
                                pickup, dropoff
                            )
                        except Exception:
                            eta = 999
                        cand["eta_min"] = eta
                        cands.append(cand)
                        print(f"[MANAGER] 📥 Candidature {cand['courier_id']} (ETA={eta} min)")

                if not cands:
                    print("[MANAGER] 😕 Aucune candidature reçue.")
                    continue

                # Tri par ETA puis par sent_at (tiebreak)
                cands.sort(key=lambda c: (c.get("eta_min", 999), c.get("sent_at", 0)))

                # ⬇️ NOUVEAUTÉ : choix MANUEL ou AUTO (Entrée)
                chosen = prompt_select_or_auto(cands)

                assignments.insert_one({
                    "type": "SELECTION",
                    "order_id": order_id,
                    "courier_id": chosen["courier_id"],
                    "courier_name": chosen.get("name", chosen["courier_id"]),
                    "eta_min": int(chosen.get("eta_min", 10)),
                    "reward_eur": REWARD_EUR,
                    "pickup":  {"lat": pickup["lat"],  "lon": pickup["lon"]},
                    "dropoff": {"lat": dropoff["lat"], "lon": dropoff["lon"]},
                    "assigned_at": int(time.time())
                })
                print(f"[MANAGER] ✅ Affecté: {chosen['courier_id']} | ETA {int(chosen.get('eta_min', 10))} min")

    except KeyboardInterrupt:
        print("\n[MANAGER] Arrêt.")
    finally:
        client.close()

if __name__ == "__main__":
    main()
