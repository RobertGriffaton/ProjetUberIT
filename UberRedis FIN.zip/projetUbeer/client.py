# client.py — envoie une commande et suit le livreur en temps réel
import csv, json, time, uuid
import redis

CHANNEL_ORDERS    = "orders.new"
CHANNEL_SELECTION = "annonces.selection"
CHANNEL_TRACKING  = "tracking.updates"

CSV_MENUS = "menus.csv"
REDIS_URL = "redis://localhost:6379/0"

CLIENT_LAT = 48.8610
CLIENT_LON = 2.3450

def load_menus(csv_file):
    restos = {}
    with open(csv_file, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            restos.setdefault(row["restaurant"], []).append(row)
    return restos

def main():
    r = redis.from_url(REDIS_URL, decode_responses=True)
    restos = load_menus(CSV_MENUS)

    print("Restaurants disponibles:")
    names = list(restos.keys())
    for i, name in enumerate(names, 1):
        print(f"{i}) {name}")
    idx = int(input("Choisir un restaurant: ")) - 1
    resto = names[idx]

    print(f"Menu de {resto}:")
    menu = restos[resto]
    for j, row in enumerate(menu, 1):
        print(f"{j}) {row['item']} — {row['price_eur']}€ (sku={row['sku']})")
    k = int(input("Choisir un plat: ")) - 1
    item = menu[k]

    order_id = str(uuid.uuid4())
    order = {
        "type": "ORDER",
        "order_id": order_id,
        "customer": {"name": "Client POC", "lat": CLIENT_LAT, "lon": CLIENT_LON},
        "restaurant": {"name": resto},
        "items": [{"sku": item["sku"], "qty": 1}],
        "created_at": int(time.time()),
    }
    r.publish(CHANNEL_ORDERS, json.dumps(order))
    print(f"[CLIENT] 🧾 Commande envoyée: {order_id} → {resto} / {item['item']}")

    # 1) attendre la SELECTION
    sub = r.pubsub(); sub.subscribe(CHANNEL_SELECTION)
    print("[CLIENT] ⏳ En attente d'attribution d'un coursier…")
    courier_id = None; courier_name = None
    try:
        for msg in sub.listen():
            if msg["type"] != "message":
                continue
            try:
                data = json.loads(msg["data"])
            except Exception:
                continue
            if data.get("type") == "SELECTION" and data.get("order_id") == order_id:
                courier_id = data["courier_id"]
                courier_name = data.get("courier_name", courier_id)
                print(f"[CLIENT] ✅ Livreur attribué: {courier_name} (ID={courier_id}, ETA≈{data.get('eta_min','?')} min, prime={data.get('reward_eur','?')}€)")
                break
    finally:
        try: sub.close()
        except: pass

    if not courier_id:
        print("[CLIENT] ❌ Pas de coursier attribué. Abandon.")
        return

    # 2) suivi en temps réel
    print("[CLIENT] 🚴 Suivi en temps réel… (Ctrl+C pour quitter l’affichage)")
    sub2 = r.pubsub(); sub2.subscribe(CHANNEL_TRACKING)
    try:
        for msg in sub2.listen():
            if msg["type"] != "message":
                continue
            try:
                t = json.loads(msg["data"])
            except Exception:
                continue
            if t.get("type") != "TRACK": 
                continue
            if t.get("order_id") != order_id or t.get("courier_id") != courier_id:
                continue

            status = t.get("status", "")
            lat = float(t.get("lat"))
            lon = float(t.get("lon"))
            progress = int(t.get("progress", 0))
            eta_s = int(t.get("eta_s", 0))

            print(f"[SUIVI] {status:<18} | pos=({lat:.5f},{lon:.5f}) | prog={progress:>3}% | eta~{eta_s:>2}s")

            if status in ("vers_client_arrived", "livre"):
                print("[CLIENT] 🎉 Livraison terminée. Merci !")
                break
    except KeyboardInterrupt:
        print("\n[CLIENT] Arrêt du suivi.")
    finally:
        try: sub2.close()
        except: pass

if __name__ == "__main__":
    main()
