# coursier.py — accepte (o/N) puis publie un tracking en temps réel
import json, math, os, random, socket, time, uuid
import redis

# Canaux
CHANNEL_ANNONCES      = "annonces.new"
CHANNEL_CANDIDATURES  = "candidatures.new"
CHANNEL_SELECTION     = "annonces.selection"
CHANNEL_TRACKING      = "tracking.updates"

# Réglages
REDIS_URL      = "redis://localhost:6379/0"
VITESSE_KMH    = 14.0
DELAI_FIXE_MIN = 2.0
CENTER_LAT     = 48.8660
CENTER_LON     = 2.3350
JITTER_KM      = 0.3
TICK_SEC       = 1.0

NAMES = ["Alex","Sam","Robin","Camille","Noa","Lina","Mael","Eli","Nora","Rayan","Milan","Yanis","Léa","Jules","Zoé","Léo","Inès","Sacha","Aya","Nils"]

def unique_id(prefix="c"):
    host = socket.gethostname().split(".")[0]
    pid = os.getpid()
    short = str(uuid.uuid4())[:4]
    return f"{prefix}_{host}_{pid}_{short}"

def pick_name():
    return f"{random.choice(NAMES)}-{str(uuid.uuid4())[:3]}"

def jitter_position(lat0, lon0, spread_km=JITTER_KM):
    d_km_lat = random.gauss(0, spread_km)
    d_km_lon = random.gauss(0, spread_km)
    dlat = d_km_lat / 111.0
    dlon = d_km_lon / (111.0 * max(0.1, math.cos(math.radians(lat0))))
    return lat0 + dlat, lon0 + dlon

def haversine_km(a_lat, a_lon, b_lat, b_lon):
    R = 6371.0
    dlat = math.radians(b_lat - a_lat)
    dlon = math.radians(b_lon - a_lon)
    lat1 = math.radians(a_lat); lat2 = math.radians(b_lat)
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2*R*math.asin(math.sqrt(h))

def lerp(a, b, t):
    return a + (b - a) * t

def move_and_track(r, order_id, courier_id, name, start, target, status_label, speed_kmh=VITESSE_KMH):
    lat, lon = start
    lat_t, lon_t = target
    dist_km = max(1e-6, haversine_km(lat, lon, lat_t, lon_t))
    duration_s = (dist_km / max(1e-6, speed_kmh)) * 3600.0
    duration_s = max(5.0, duration_s + random.uniform(-5, 10))
    steps = max(5, int(duration_s // TICK_SEC))
    t0 = time.time()

    last_shown = -25  # pour forcer le premier affichage à 0%

    for step in range(steps + 1):
        t = step / steps
        cur_lat = lerp(lat, lat_t, t)
        cur_lon = lerp(lon, lon_t, t)
        progress = int(round(t * 100))
        # 🔹 n’envoie que tous les 25 %
        if progress - last_shown < 25 and progress != 100:
            time.sleep(TICK_SEC)
            continue
        last_shown = progress

        update = {
            "type": "TRACK",
            "order_id": order_id,
            "courier_id": courier_id,
            "name": name,
            "status": status_label,
            "lat": cur_lat,
            "lon": cur_lon,
            "progress": progress,
            "eta_s": int(max(0, duration_s - (time.time() - t0))),
            "sent_at": int(time.time())
        }
        r.publish(CHANNEL_TRACKING, json.dumps(update))
        time.sleep(TICK_SEC)

    # 🔹 message final à 100 %
    final_update = {
        "type": "TRACK",
        "order_id": order_id,
        "courier_id": courier_id,
        "name": name,
        "status": f"{status_label}_arrived",
        "lat": lat_t,
        "lon": lon_t,
        "progress": 100,
        "eta_s": 0,
        "sent_at": int(time.time())
    }
    r.publish(CHANNEL_TRACKING, json.dumps(final_update))


def main():
    coursier_id = unique_id()
    name = pick_name()
    lat, lon = jitter_position(CENTER_LAT, CENTER_LON, JITTER_KM)

    r = redis.from_url(REDIS_URL, decode_responses=True)
    sub = r.pubsub(); sub.subscribe(CHANNEL_ANNONCES, CHANNEL_SELECTION)

    print(f"[COURSIER {coursier_id}] En ligne | nom={name} | pos=({lat:.5f},{lon:.5f}) | v={VITESSE_KMH}km/h")

    pending = set()
    orders_ctx = {}  # order_id -> {"pickup":{lat,lon}, "dropoff":{lat,lon}}

    try:
        for msg in sub.listen():
            if msg.get("type") != "message":
                continue
            try:
                data = json.loads(msg["data"])
            except Exception:
                continue

            if data.get("type") == "ANNONCE":
                order_id = data.get("order_id")
                if not order_id or order_id in pending:
                    continue
                pickup = data.get("pickup") or {}
                drop   = data.get("dropoff") or {}
                if not pickup or not drop:
                    print(f"[{coursier_id}] ⚠️ annonce mal formée"); 
                    continue

                # mémorise pour la suite
                orders_ctx[order_id] = {
                    "pickup": {"lat": float(pickup["lat"]), "lon": float(pickup["lon"])},
                    "dropoff": {"lat": float(drop["lat"]), "lon": float(drop["lon"])},
                }

                d1 = haversine_km(lat, lon, float(pickup["lat"]), float(pickup["lon"]))
                d2 = haversine_km(float(pickup["lat"]), float(pickup["lon"]), float(drop["lat"]), float(drop["lon"]))
                total_km = d1 + d2
                minutes = (total_km / max(1e-6, VITESSE_KMH)) * 60.0 + DELAI_FIXE_MIN
                eta = max(1, int(round(minutes + random.uniform(-0.2, 0.4))))
                print(f"[COURSIER {coursier_id}] 📣 Annonce {order_id} | dist≈{total_km:.2f} km | ETA≈{eta} min | prime≈{data.get('reward_eur','?')}€")

                try:
                    choice = input(f"[{name}] Accepter ? (o/N) ").strip().lower()
                except EOFError:
                    choice = "n"

                if choice == "o":
                    cand = {
                        "type": "CANDIDATURE",
                        "order_id": order_id,
                        "courier_id": coursier_id,
                        "name": name,
                        "eta_min": eta,
                        "position": {"lat": lat, "lon": lon},
                        "sent_at": int(time.time()),
                    }
                    r.publish(CHANNEL_CANDIDATURES, json.dumps(cand))
                    pending.add(order_id)
                    print(f"[COURSIER {coursier_id}] 📨 Candidature envoyée (ETA={eta} min)")

            elif data.get("type") == "SELECTION":
                if data.get("courier_id") != coursier_id:
                    continue
                order_id = data["order_id"]
                ctx = orders_ctx.get(order_id)
                if not ctx:
                    # fallback : utiliser les champs envoyés par le manager
                    if "pickup" in data and "dropoff" in data:
                        ctx = {"pickup": data["pickup"], "dropoff": data["dropoff"]}
                    else:
                        print(f"[COURSIER {coursier_id}] ⚠️ pas de contexte pour {order_id}")
                        continue

                print(f"[COURSIER {coursier_id}] ✅ Sélectionné pour {order_id} — départ…")

                # 1) vers le resto
                move_and_track(
                    r, order_id, coursier_id, name,
                    start=(lat, lon),
                    target=(float(ctx["pickup"]["lat"]), float(ctx["pickup"]["lon"])),
                    status_label="vers_resto",
                    speed_kmh=VITESSE_KMH
                )
                time.sleep(2)

                # 2) vers le client (mise à jour de la position après 1er tronçon)
                lat, lon = float(ctx["pickup"]["lat"]), float(ctx["pickup"]["lon"])
                move_and_track(
                    r, order_id, coursier_id, name,
                    start=(lat, lon),
                    target=(float(ctx["dropoff"]["lat"]), float(ctx["dropoff"]["lon"])),
                    status_label="vers_client",
                    speed_kmh=VITESSE_KMH
                )

                # Fin
                lat, lon = float(ctx["dropoff"]["lat"]), float(ctx["dropoff"]["lon"])
                done = {
                    "type": "TRACK",
                    "order_id": order_id,
                    "courier_id": coursier_id,
                    "name": name,
                    "status": "livre",
                    "lat": lat,
                    "lon": lon,
                    "progress": 100,
                    "eta_s": 0,
                    "sent_at": int(time.time())
                }
                r.publish(CHANNEL_TRACKING, json.dumps(done))
                print(f"[COURSIER {coursier_id}] 📦 Livraison terminée pour {order_id} ✅")
                pending.discard(order_id)
                orders_ctx.pop(order_id, None)

    except KeyboardInterrupt:
        print("\n[COURSIER] Arrêt demandé. Bye.")
    finally:
        try: sub.close()
        except: pass

if __name__ == "__main__":
    main()
