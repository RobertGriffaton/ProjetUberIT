# Ubeer (POC Redis Pub/Sub)

Petit projet d’école : simuler une plateforme type UberEats en utilisant **Redis Pub/Sub**.  
Rôles :

- **client.py** — le “client” choisit un resto + un plat (depuis `menus.csv`) et publie une commande.
- **manager.py** — reçoit la commande, publie une **annonce** aux coursiers, collecte les **candidatures**, sélectionne le meilleur.
- **coursier.py** — écoute les annonces, calcule un **ETA basé sur la distance** (Haversine) et une **vitesse km/h**, candidate, puis reçoit la sélection.

---

## 1) Prérequis

- **Windows 10/11**
- **Python 3.10+** installé (commande `py --version` doit fonctionner).
- **Redis** en local. Plusieurs options :
  1. **Docker Desktop (recommandé)** : lancer un conteneur Redis en 1 ligne.
  2. **WSL2** (Ubuntu) : installer Redis dans la distro.
  3. **Alternative Windows** (si tu n’utilises pas Docker/WSL) : un serveur Redis natif (ex. port 6379).

> Pour ce POC, l’option **Docker** est la plus simple.

---

## 2) Démarrage rapide (PowerShell)

Ouvre **PowerShell** dans le dossier du projet (là où se trouvent `client.py`, `manager.py`, `coursier.py`, `menus.csv`).

### 2.1 Créer et activer un environnement virtuel

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```
