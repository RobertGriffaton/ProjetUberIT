# manager.py — gère annonces, collecte candidatures, attribution (manuelle ou auto)
import csv, json, time
import redis

# Canaux
CHANNEL_ORDERS        = "orders.new"
CHANNEL_ANNONCES      = "annonces.new"
CHANNEL_CANDIDATURES  = "candidatures.new"
CHANNEL_SELECTION     = "annonces.selection"

# Réglages
CSV_MENUS   = "menus.csv"
REDIS_URL   = "redis://localhost:6379/0"
REWARD_EUR  = 8.5
TIMEOUT_S   = 15  # fenêtre d'attente des candidatures

def load_restaurants(csv_file):
    restos = {}
    with open(csv_file, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            name = row["restaurant"].strip()
            lat = float(row["latitude"]); lon = float(row["longitude"])
            if name not in restos:
                restos[name] = {"lat": lat, "lon": lon}
    return restos

def choose_best_eta(cands):
    if not cands: return None
    cands = sorted(cands, key=lambda c: (c["eta_min"], c["sent_at"]))
    return cands[0]

def prompt_select_or_auto(cands):
    if not cands:
        return None
    print("\n[MANAGER] 📊 Candidatures reçues :")
    ordered = sorted(cands, key=lambda x: (x["eta_min"], x["sent_at"]))
    for i, c in enumerate(ordered, 1):
        print(f"  {i}) courier_id={c['courier_id']:<22} nom={c.get('name','-'):<12} ETA={c['eta_min']:>2} min")
    try:
        raw = input("[MANAGER] Choisir (1..N) ou Entrée pour auto : ").strip()
    except EOFError:
        raw = ""
    if raw == "":
        return ordered[0]
    try:
        idx = int(raw)
        if 1 <= idx <= len(ordered):
            return ordered[idx-1]
    except Exception:
        pass
    print("[MANAGER] Saisie invalide → auto.")
    return ordered[0]

def main():
    restos = load_restaurants(CSV_MENUS)
    r = redis.from_url(REDIS_URL, decode_responses=True)
    sub_orders = r.pubsub(); sub_orders.subscribe(CHANNEL_ORDERS)
    print("[MANAGER] En écoute sur les commandes…")

    try:
        for msg in sub_orders.listen():
            if msg["type"] != "message": 
                continue
            try:
                order = json.loads(msg["data"])
            except Exception:
                continue
            if order.get("type") != "ORDER":
                continue

            order_id   = order["order_id"]
            resto_name = order["restaurant"]["name"]
            client_pos = {"lat": float(order["customer"]["lat"]), "lon": float(order["customer"]["lon"])}

            if resto_name not in restos:
                print(f"[MANAGER] ❌ Restaurant inconnu: {resto_name}")
                continue

            annonce = {
                "type": "ANNONCE",
                "order_id": order_id,
                "pickup": {"name": resto_name, **restos[resto_name]},
                "dropoff": client_pos,
                "reward_eur": REWARD_EUR,
                "deadline_s": TIMEOUT_S,
                "created_at": int(time.time()),
            }
            r.publish(CHANNEL_ANNONCES, json.dumps(annonce))
            print(f"[MANAGER] 📣 Annonce publiée pour {order_id} ({resto_name}) — attente {TIMEOUT_S}s")

            # collecte des candidatures
            sub_c = r.pubsub(); sub_c.subscribe(CHANNEL_CANDIDATURES)
            candidatures = []
            t_end = time.monotonic() + TIMEOUT_S
            while time.monotonic() < t_end:
                msg2 = sub_c.get_message(ignore_subscribe_messages=True, timeout=0.3)
                if not msg2:
                    continue
                try:
                    c = json.loads(msg2["data"])
                except Exception:
                    continue
                if c.get("type") != "CANDIDATURE" or c.get("order_id") != order_id:
                    continue
                candidatures.append(c)
                print(f"[MANAGER] 📥 Candidature de {c['courier_id']} (ETA={c['eta_min']} min)")

            if not candidatures:
                print("[MANAGER] 😕 Aucune candidature reçue.")
                continue

            chosen = prompt_select_or_auto(candidatures)
            if not chosen:
                print("[MANAGER] ❌ Pas de sélection.")
                continue

            selection = {
                "type": "SELECTION",
                "order_id": order_id,
                "courier_id": chosen["courier_id"],
                "courier_name": chosen.get("name", chosen["courier_id"]),
                "eta_min": chosen["eta_min"],
                "reward_eur": REWARD_EUR,
                # ⬇️ indispensables pour le tracking
                "pickup": annonce["pickup"],
                "dropoff": annonce["dropoff"],
                "assigned_at": int(time.time()),
            }
            r.publish(CHANNEL_SELECTION, json.dumps(selection))
            print(f"[MANAGER] ✅ Affecté: {selection['courier_id']} ({selection['courier_name']}) | ETA={selection['eta_min']} min")

    except KeyboardInterrupt:
        print("\n[MANAGER] Arrêt demandé. Bye.")
    finally:
        try: sub_orders.close()
        except: pass

if __name__ == "__main__":
    main()
